//npm install express nodemon

const express = require('express')
const app = express()

//midlewares
app.use(express.urlencoded(
    {extended:true,}
),)
app.use(express.json())

//Rota inicial
app.get('/', (req,res) => {
    res.status(200).json(
        {
            message : 'Primeira API criada com sucesso'
        }
    )
})

//Rota de criação de produtos
app.post('/criarproduto',(req,res) =>{
    const nome = req.body.nome
    const preco = req.body.preco

    if (!nome){
        res.status(422).json({
            message: "Faltou informar o nome do produto"
        })
        return
    }

    res.status(201).json({
        message : `Produto ${nome} criado com sucesso`
    })
}

)

app.listen(3000)