import socket
import time

def main():
    host = 'localhost'
    port = 12345
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"Aguardando conexões em {host}:{port}")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexão recebida de {addr}")
        server_time = time.time() + 2 # Introduzindo um atraso de 2 segundos no relógio do servidor
        server_time_string = str(server_time)
        client_socket.send(server_time_string.encode())
        client_time_string = client_socket.recv(1024).decode()
        client_time = float(client_time_string)
        adjustment = server_time - client_time #ajuste do horario
        client_socket.send(str(adjustment).encode())
        client_socket.close()

if __name__ == '__main__':
    main()