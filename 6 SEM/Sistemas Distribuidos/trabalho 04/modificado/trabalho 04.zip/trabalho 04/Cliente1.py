import socket
import time
import threading

def clock(name, client_socket, barrier):
    while True:
        # Obtem a hora do servidor
        server_time_str = client_socket.recv(1024).decode()
        if server_time_str:
            server_time = float(server_time_str)
            print(f"{name} Relógio: {server_time}")
        
        # Aguarda a barreira para sincronizar as threads
        barrier.wait()
        time.sleep(5)

def main():
    host = 'localhost'
    port = 12345

    # Cria uma conexão com o servidor
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect((host, port))

    # Crie uma barreira para sincronizar as threads
    barrier = threading.Barrier(4)

    # Cria threads para os relógios
    clock1 = threading.Thread(target=clock, args=('Clock1', client_socket, barrier))
    clock2 = threading.Thread(target=clock, args=('Clock2', client_socket, barrier))
    clock3 = threading.Thread(target=clock, args=('Clock3', client_socket, barrier))
    clock4 = threading.Thread(target=clock, args=('Clock4', client_socket, barrier))

    # Inicia os threads
    clock1.start()
    clock2.start()
    clock3.start()
    clock4.start()

    # Espera os threads terminarem
    clock1.join()
    clock2.join()
    clock3.join()
    clock4.join()

    # Fecha a conexão com o servidor
    client_socket.close()

if __name__ == '__main__':
    main()
