package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF6200EE)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF03DAC5)

val Blue1 = Color(0xFF223344)
val Blue2 = Color(0xFF2A3E53)
val Blue3 = Color(0xFF1D2838)

val Gray1 = Color(0xFFB4BFBC)

val Green1 = Color(0xFF9FE234)