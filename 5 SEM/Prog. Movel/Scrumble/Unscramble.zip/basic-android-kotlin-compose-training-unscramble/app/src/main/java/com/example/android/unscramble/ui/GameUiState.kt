package com.example.android.unscramble.ui

data class GameUiState(
    val scrambleWorld:String="",
    val wordsNumber:Int=1,
    val score:Int=0,
    val isGameOver:Boolean=false,
    val isGuessWrong:Boolean=false,

    )
