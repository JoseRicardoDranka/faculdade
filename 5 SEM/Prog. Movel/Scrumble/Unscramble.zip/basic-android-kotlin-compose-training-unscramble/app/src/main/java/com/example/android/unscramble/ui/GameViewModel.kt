package com.example.android.unscramble.ui

import androidx.lifecycle.ViewModel
import com.example.android.unscramble.data.SCORE_INCREASE
import com.example.android.unscramble.data.allWords
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class GameViewModel : ViewModel() {
    //controla view e eventos
    private var _uiState: MutableStateFlow<GameUiState> = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    private lateinit var currentWord: String
    private var usedWords: MutableSet<String> = mutableSetOf()

    private var _currentGuess: MutableStateFlow<String> = MutableStateFlow("")
    val currentGuess: StateFlow<String> = _currentGuess.asStateFlow()

    init {
        resetGame()
    }

    fun resetGame() {
        usedWords.clear()
        _uiState.value = GameUiState(scrambleWorld = getWordAndShuffle())
    }


    private fun getWordAndShuffle(): String {
        currentWord = allWords.random()
        if (usedWords.contains(currentWord)) {
            return getWordAndShuffle()
        } else {
            usedWords.add(currentWord)
            var word = currentWord.toCharArray()
            word.shuffle()
            return String(word)
        }


    }

    fun updateGuessWord(guess: String) {
        _currentGuess.value = guess
    }

    fun checkGuessWord() {
        if (_currentGuess.value == currentWord) {
            _uiState.update { currentState ->
                currentState.copy(
                    score = currentState.score + SCORE_INCREASE,
                    scrambleWorld = getWordAndShuffle(),
                    wordsNumber = currentState.wordsNumber + 1,
                    isGuessWrong = false,
                )
            }
        } else {
            _uiState.update { currentState ->
                currentState.copy(
                    isGuessWrong = true
                )
            }
        }
        _currentGuess.value=""
    }

}