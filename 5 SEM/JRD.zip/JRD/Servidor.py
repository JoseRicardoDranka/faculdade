import socket 
   
def Main(): 
    host = "" 
    port = 2802
    bufferSize = 1024

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM) 
    server_socket.bind((host, port)) 
  
    print("Servidor inicializado na porta " + str(port))

    while True: 
        bytesAddressPair = server_socket.recvfrom(bufferSize)
        
        message = bytesAddressPair[0]
        address = bytesAddressPair[1]

        clientMsg = "{}".format(message)
        clientIP  = "Client IP Address:{}".format(address)

        print(clientMsg)
        print(clientIP)

        frase = clientMsg
        invertida = ' '.join(palavra[::-1] for palavra in frase.split())




        msgFromServer = invertida
        bytesToSend = str.encode(msgFromServer)
        

        server_socket.sendto(bytesToSend, address)

if __name__ == '__main__': 
    Main() 