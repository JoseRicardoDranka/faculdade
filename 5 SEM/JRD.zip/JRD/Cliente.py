import socket 

def Main(): 

    host = '127.0.0.1'
    port = 2802
    
    msg = "I.F.S.C"
    #bytes_envio = str.encode(msg)
    endereco_servidor =("127.0.0.1",2802)
    bufferSize = 1024


    client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    client_socket.sendto(msg.encode(),endereco_servidor)


    msgFromServer = client_socket.recvfrom(bufferSize)


    msg = "Message from Server: {}".format(msgFromServer[0])

    print(msg)

    client_socket.close() #Fecha a conexão com o servidor

if __name__ == '__main__': 
	Main()